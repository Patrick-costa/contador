<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
</head>

<body>
    <?php 

include './crud/conexao.php';

$query = "select SUM(cont) AS total 
FROM contador";


$result = mysqli_query($con, $query);

$row = mysqli_num_rows($result);

$return = mysqli_fetch_assoc($result);

$var = $return['total'];



?>


<input id="contador" value='<?=$var?>' type="hidden">

    <form action="./crud/registrar.php" method="POST" id="form">
        <label for="nome">Nome</label>
        <input type="text" name="nome">
        <br><br>
        <label for="cpf">CPF</label>
        <input type="text" name="cpf">
        <br><br>
        <input type="hidden" name="numero" value='1'>
        <button type="submit" form="form">Enviar</button>

    </form>

    Quantidade de cadastros
    <div class="container"><p id="vel"></p>
</div>


    <script type="text/javascript">
        
function tempo(y){
    var cont = $('#contador').val();
   y -= 30;
   
   var time = setTimeout(function() {
      x++;
      var cont = $('#contador').val();
      document.getElementById("vel").innerHTML = x;
      tempo(y);
      clearInterval(parseInt(1)+parseInt(cont));
   }, y,);
}

var x = 0;
var y = 100;
document.getElementById("vel").innerHTML = x;

tempo(y);


    </script>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script> <!-- add Jquery CDN -->
</body>

</html>