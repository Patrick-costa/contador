<?php 
include 'conexao.php';

$query = "select SUM(cont) AS total 
FROM contador";


$result = mysqli_query($con, $query);

$row = mysqli_num_rows($result);

$return = mysqli_fetch_assoc($result);

$var = $return['total'];

