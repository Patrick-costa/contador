
create database cont;

use cont;

create table contador(
	id int primary key,
    usuario varchar(255),
    cpf varchar(20) unique
);

