<?php

require 'crud.php';

if($_SERVER['REQUEST_METHOD'] === "POST"){
    $usuario = filter_input(INPUT_POST, "nome") ?? "";
    $cpf = filter_input(INPUT_POST, "cpf") ?? "";
    $numero = filter_input(INPUT_POST, "numero") ?? "";


    if(cadastrarUser($usuario,$cpf,$numero)){
        echo " Usuario cadastrado com sucesso ";
        header('location: ../index.php');
    } else{
        echo " Erro ao gravar usuario ";
    }

}