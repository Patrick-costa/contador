<?php

    require('conexao.php');
    ## ARQUIVO RESPONSAVEL POR FAZER AS TRANSAÇÕES COM O BANCO DE DADOS ##

    //Função para cadastrar as grades

function cadastrarUser($usuario,$cpf,$numero){

    $link = abreConexao();

    $query = "insert into contador(usuario,cpf,cont) value('{$usuario}','{$cpf}',{$numero})";

    echo $query."<br>";

    try{
        if(mysqli_query($link, $query)){
                return true;
            } 
    } catch(\Throwable $th){
        throw new \Exception("Erro ao gravar no banco", 1);
        return false;
    } finally{
        mysqli_close($link);
    }
}